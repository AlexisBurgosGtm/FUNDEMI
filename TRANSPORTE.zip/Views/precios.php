
<?php include('Views/header.php'); ?>

            <div class="content">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title">Lista de Precios</h5>
                            </div>
                            <div class="card-body">

                              <?php include('Reports/data_precios.php'); ?>

                            </div>
                        </div>

                    </div>

                </div>
            </div>

<?php include('Views/footer.php'); ?>
